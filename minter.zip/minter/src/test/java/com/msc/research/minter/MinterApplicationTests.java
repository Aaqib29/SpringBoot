package com.msc.research.minter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinterApplicationTests {

	@Test
	void contextLoads() {
	}

}
